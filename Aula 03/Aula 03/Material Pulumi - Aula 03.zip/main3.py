# Aula 03 -- Exemplo 3: Empacotando um App em .zip
# Equivalente Pulumi (Python) do main3.tf da Aula 02 (provider archive).
#
# Pre-requisitos:
#   pip install pulumi pulumi_archive
#   mkdir app
#   echo 'console.log("Ola do app de exemplo!");' > app/index.js
#
# Como rodar:
#   pulumi up

import pulumi
import pulumi_archive as archive

# equivalente a: data "archive_file" "pacote"
# os dois sao "leituras" (data source / invoke function), nao recursos
# geridos com ciclo de vida proprio -- so calculam um valor.
pacote = archive.get_file(
    type="zip",
    source_dir="app",
    output_path="app.zip",
)

# No Terraform, rodar um comando depois de criar o pacote exige um
# terraform_data + provisioner "local-exec" (a "valvula de escape" da
# linguagem). Aqui no Pulumi, e so mais uma linha do seu programa Python --
# nao existe um conceito separado de "provisioner".
print("Pacote gerado com sucesso")

# equivalente a: output "sha256_do_pacote"
pulumi.export("sha256_do_pacote", pacote.output_sha)
