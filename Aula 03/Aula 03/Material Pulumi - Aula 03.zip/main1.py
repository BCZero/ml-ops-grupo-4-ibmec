# Aula 03 -- Exemplo 1: Credenciais
# Equivalente Pulumi (Python) do main1.tf da Aula 02 (providers random + local).
#
# Pre-requisitos:
#   pip install pulumi pulumi_random
#
# Como rodar:
#   pulumi new python --force   (ou use um projeto ja criado com "pulumi new azure-python"
#                                 e adicione este conteudo no lugar do __main__.py)
#   pulumi up

import pulumi
import pulumi_random as random

# equivalente a: resource "random_pet" "usuario"
usuario = random.RandomPet(
    "usuario",
    length=2,
    separator="_",
)

# equivalente a: resource "random_password" "senha"
# nota: senha.result ja nasce como um Output "secret" -- o Pulumi mascara
# o valor no terminal e criptografa no state, sem precisar de flag extra
# (o mesmo papel do "sensitive = true" no Terraform, mas automatico).
senha = random.RandomPassword(
    "senha",
    length=16,
    special=True,
)


def salvar_credenciais(vals):
    """Escreve o arquivo local -- no Pulumi, isso NAO precisa de um provider
    dedicado (o Terraform usa local_sensitive_file); e so mais uma linha
    de Python de verdade, porque o programa roda de fato."""
    usuario_id, senha_valor = vals
    with open("credenciais.txt", "w") as f:
        f.write(f"usuario: {usuario_id}\nsenha: {senha_valor}")


# Output.all(...).apply(...) e o padrao idiomatico do Pulumi para combinar
# valores que so existem depois do deploy (equivalente a referenciar dois
# resources dentro do mesmo "content" no Terraform).
pulumi.Output.all(usuario.id, senha.result).apply(salvar_credenciais)

# equivalente a: output "usuario_gerado"
pulumi.export("usuario_gerado", usuario.id)
