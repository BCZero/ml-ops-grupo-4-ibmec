# Aula 03 -- Exemplo 5: Demo PCDF Contra o Azure
# Equivalente Pulumi (Python) do main.tf da demo real da Aula 02 (Parte 11).
#
# Pre-requisitos:
#   az login   (mesma sessao Azure CLI ja usada pelo Terraform)
#   Resource Group "rg-pcdf-demo" ja precisa existir (criado na Aula 01
#   via "az group create", igual ao pre-requisito do Terraform)
#
#   pulumi new azure-python
#   pip install -r requirements.txt   (ja inclui pulumi_azure_native)
#
# Como rodar:
#   pulumi up
#   # confira em portal.azure.com -> Resource Groups -> rg-pcdf-demo

import pulumi
from pulumi_azure_native import resources, storage

# equivalente a: data "azurerm_resource_group" "rg"
# .get() e o "data" do Pulumi -- LE um recurso que ja existe, sem geri-lo.
# Assim como no Terraform, um "pulumi destroy" nunca afeta este Resource
# Group, porque ele nunca foi "possuido" pelo Pulumi.
rg = resources.ResourceGroup.get("rg", "rg-pcdf-demo")

# equivalente a: resource "azurerm_storage_account" "st"
account = storage.StorageAccount(
    "stpcdfbopulumi",
    resource_group_name=rg.name,
    sku=storage.SkuArgs(name="Standard_LRS"),
    kind="StorageV2",
)

# equivalente a: resource "azurerm_storage_container" "raw"
container = storage.BlobContainer(
    "bos-pulumi-demo",
    account_name=account.name,
    resource_group_name=rg.name,
)

# equivalente a um output do Terraform
pulumi.export("conta_criada", account.name)
