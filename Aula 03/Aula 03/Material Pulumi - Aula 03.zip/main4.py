# Aula 03 -- Exemplo 4: Container Docker
# Equivalente Pulumi (Python) do Main4.tf da Aula 02 (provider docker/kreuzwerker).
#
# Pre-requisito: Docker Desktop instalado e RODANDO (Pendencia 1 desta aula).
#
# Pre-requisitos de pacote:
#   pip install pulumi pulumi_docker
#
# Como rodar:
#   pulumi up
#   # depois do apply, abra: http://localhost:8080

import pulumi
import pulumi_docker as docker

# equivalente a: resource "docker_image" "nginx"
nginx = docker.RemoteImage(
    "nginx",
    name="nginx:latest",
)

# equivalente a: resource "docker_container" "site"
site = docker.Container(
    "site",
    name="meu-site-local",
    image=nginx.image_id,
    ports=[docker.ContainerPortArgs(
        internal=80,
        external=8080,
    )],
)

# equivalente a: output "acesse_em"
pulumi.export("acesse_em", "http://localhost:8080")
