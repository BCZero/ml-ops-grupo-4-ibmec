# Aula 03 -- Exemplo 2: Par de Chaves SSH
# Equivalente Pulumi (Python) do main2.tf da Aula 02 (provider tls).
#
# Pre-requisitos:
#   pip install pulumi pulumi_tls
#
# Como rodar:
#   pulumi up
#   # depois do apply, teste com: ssh-keygen -lf id_rsa.pub

import pulumi
import pulumi_tls as tls

# equivalente a: resource "tls_private_key" "chave"
chave = tls.PrivateKey(
    "chave",
    algorithm="RSA",
    rsa_bits=4096,
)


def salvar_chaves(vals):
    """Assim como a senha do Exemplo 1, private_key_pem tambem nasce
    marcado como secreto -- o Pulumi propaga essa marcacao vinda do
    schema do provider (mesma origem do "sensitive" no Terraform)."""
    privada, publica = vals
    with open("id_rsa", "w") as f:
        f.write(privada)
    with open("id_rsa.pub", "w") as f:
        f.write(publica)


pulumi.Output.all(
    chave.private_key_pem,
    chave.public_key_openssh,
).apply(salvar_chaves)

# equivalente a: output "fingerprint"
pulumi.export("fingerprint", chave.public_key_fingerprint_sha256)
