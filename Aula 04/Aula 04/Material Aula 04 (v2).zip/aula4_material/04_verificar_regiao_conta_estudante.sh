#!/usr/bin/env bash
# Aula 04 -- Descobrir QUAIS regioes sao permitidas na SUA conta
# "Azure for Students", antes de rodar Terraform ou Pulumi.
#
# Contas de estudante tem uma politica do Azure ("Allowed locations")
# que restringe em quais regioes voce pode criar recursos. Essa lista
# muda de aluno para aluno -- "brazilsouth" costuma NAO aparecer para
# muita gente. Nao adianta adivinhar: sempre confira antes.

az login

# lista as atribuicoes de politica (policy assignments) da sua assinatura
az policy assignment list \
  --query "[?contains(displayName, 'location') || contains(displayName, 'Location') || contains(displayName, 'região') || contains(displayName, 'regiao')].{nome:displayName, id:name}" \
  -o table

# depois de identificar o "id" (coluna "name") do assignment acima,
# rode o comando abaixo trocando <ID_DO_ASSIGNMENT> para ver a lista
# exata de regioes liberadas:
#
#   az policy assignment show --name <ID_DO_ASSIGNMENT> \
#     --query "parameters.listOfAllowedLocations.value" -o tsv

# ---------------------------------------------------------------------
# Caminho alternativo (mais visual), pelo Portal:
# ---------------------------------------------------------------------
#   portal.azure.com -> Policy -> Authoring -> Assignments
#     -> abra a atribuicao "Allowed locations" (ou nome parecido)
#     -> parametro "Allowed locations" mostra a lista exata

# ---------------------------------------------------------------------
# Regioes mais comumente liberadas nas contas de estudante (teste nesta
# ordem se a lista acima nao aparecer clara -- NUNCA garanta 100%):
# ---------------------------------------------------------------------
#   eastus
#   eastus2
#   westus2
#   westeurope
#   brazilsouth   (nem sempre disponivel para conta de estudante)

# ---------------------------------------------------------------------
# Se o comando acima voltar VAZIO (normal em muitas contas de estudante --
# a restricao as vezes vive num nivel que voce nao tem permissao de ler):
# ---------------------------------------------------------------------
# confirme rodando sem filtro:
az policy assignment list -o table

# se continuar vazio, va direto para o teste por tentativa direta --
# funciona mesmo sem enxergar a policy:
az group create --name rg-teste-regiao --location eastus
# deu certo? essa e a regiao liberada -- apague o grupo de teste:
#   az group delete --name rg-teste-regiao --yes --no-wait
# deu erro RequestDisallowedByPolicy? troque "eastus" pela proxima
# regiao da lista abaixo e tente de novo

# Depois de descobrir a regiao liberada, use-a nas variaveis do projeto:
#   Terraform:  variable "location" { default = "eastus" }
#   Pulumi:     pulumi config set localizacao eastus
