#!/usr/bin/env bash
# Aula 04 -- Instalar Docker Engine SEM Docker Desktop, em maquinas Windows
# que NAO tem permissao para instalar o Docker Desktop.
#
# Pre-requisito: o WSL2 (Windows Subsystem for Linux) PRECISA estar liberado
# pelo TI do cliente. Isso e diferente de "instalar Docker Desktop" -- o
# WSL2 e um recurso nativo do Windows, ativado por um comando do proprio
# Windows, sem instalar nenhum programa de terceiros.

# ---------------------------------------------------------------------
# PASSO 1 -- rodar no PowerShell do Windows, COMO ADMINISTRADOR
# ---------------------------------------------------------------------
#   wsl --install
#   (reinicie o computador se for pedido)
#   # por padrao instala o Ubuntu -- abra o "Ubuntu" no menu Iniciar
#   # na primeira vez, crie um usuario e senha Linux (fica soh na WSL)

# ---------------------------------------------------------------------
# PASSO 2 -- a partir daqui, TUDO roda dentro do terminal Ubuntu (WSL2)
# Os comandos abaixo sao EXATAMENTE os mesmos usados em uma maquina Linux.
# ---------------------------------------------------------------------

# instala o Docker Engine (script oficial e convenience script da Docker)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# permite rodar "docker" sem sudo
sudo usermod -aG docker $USER

# ---------------------------------------------------------------------
# PARE AQUI: feche esta janela do terminal e abra "Ubuntu" de novo pelo
# menu Iniciar. O usermod acima so vale para sessoes NOVAS -- fechar e
# reabrir o terminal aplica a permissao em qualquer distro, sem depender
# de comando extra (nao use "newgrp docker": nem toda distro o instala
# por padrao).
# ---------------------------------------------------------------------

# depois de reabrir o terminal, inicia o servico do Docker dentro da WSL
# (a WSL nao usa systemd por padrao em todas as versoes -- por isso
# "service", nao "systemctl")
sudo service docker start

# valida a instalacao
docker --version
docker run hello-world
docker ps
# "docker ps" vazio aqui e NORMAL: ele so lista containers RODANDO agora,
# e o hello-world ja rodou, imprimiu a mensagem e terminou (exit) sozinho.
# para ver o hello-world ja finalizado, use: docker ps -a
