#!/usr/bin/env bash
# Aula 04 -- Habilitar Kubernetes local SEM o toggle do Docker Desktop.
#
# Identico para WSL2 (Windows) e Linux -- o "kind" (Kubernetes-IN-Docker)
# e o mesmo mecanismo que o Docker Desktop usava por tras do botao
# "Enable Kubernetes" (Manual da Aula 01). So estamos chamando ele
# diretamente, via linha de comando.
#
# Pre-requisito: Docker Engine ja instalado e rodando
#   (01_instalar_docker_wsl2.sh ou 02_instalar_docker_linux.sh)

# instala o binario do kind
curl -Lo ./kind https://kind.sigs.k8s.io/dl/latest/kind-linux-amd64
chmod +x ./kind
sudo mv ./kind /usr/local/bin/kind

# instala o kubectl, se ainda nao tiver
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl
sudo mv kubectl /usr/local/bin/

# cria o cluster local (equivalente ao "Enable Kubernetes" do Docker Desktop)
kind create cluster --name mlops-local

# confirma que o kubectl esta apontando para o cluster novo
kubectl config current-context
# resultado esperado: kind-mlops-local

kubectl get nodes
# resultado esperado: 1 node com status "Ready"

# ---------------------------------------------------------------------
# Para apagar o cluster ao final (libera memoria/CPU):
# ---------------------------------------------------------------------
#   kind delete cluster --name mlops-local
