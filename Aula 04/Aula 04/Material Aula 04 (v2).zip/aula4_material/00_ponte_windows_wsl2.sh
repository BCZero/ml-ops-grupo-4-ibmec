#!/usr/bin/env bash
# Aula 04 -- Ponte entre o Windows e o terminal Ubuntu (WSL2): onde
# ficam os seus arquivos, e como trazer o projeto PCDF para dentro do
# WSL2 antes de instalar qualquer coisa.
#
# O terminal Ubuntu (WSL2) NAO e cego para os seus arquivos do Windows
# -- ele so usa um caminho diferente. Todo disco do Windows (C:, D:,
# G:, etc.) aparece dentro do WSL2 em /mnt/<letra-minuscula>/ -- e o
# WSL2 tambem tem a SUA pasta pessoal Linux, em ~ (separada do Windows).

# ---------------------------------------------------------------------
# PASSO 1 -- confirmar o caminho da SUA pasta do projeto PCDF
# ---------------------------------------------------------------------
# Exemplo: se a pasta no Windows for G:\Meu Drive\TRABALHO\CORRENTES\<pasta>,
# dentro do WSL2 o MESMO caminho e: /mnt/g/Meu Drive/TRABALHO/CORRENTES/<pasta>
# -- troque a letra do disco para minuscula depois de /mnt/, e troque
# as barras invertidas \ por barras normais /.

# TROQUE pelo caminho REAL da SUA pasta do projeto PCDF no Windows:
MEU_PROJETO_WINDOWS="/mnt/g/Meu Drive/TRABALHO/CORRENTES/<pasta-do-projeto>"

# confirme que o caminho esta certo -- deve listar os arquivos da pasta:
ls "$MEU_PROJETO_WINDOWS"
# se der "No such file or directory", confira a letra do disco e o
# nome exato da pasta -- maiusculas/minusculas e acentos importam no Linux

# ---------------------------------------------------------------------
# PASSO 2 -- trazer o projeto para dentro do WSL2 (escolha UMA opcao)
# ---------------------------------------------------------------------

# Opcao A (recomendada): clonar o repositorio do GitHub direto dentro
# do WSL2, sem tocar na copia do Windows -- mais rapido, sem risco de
# erro de copia.
cd ~
git clone <URL-do-seu-repositorio-PCDF>
cd <nome-do-repositorio>

# Opcao B: copiar a pasta que ja esta no Windows para dentro do WSL2
# (use se tiver mudancas locais ainda nao enviadas ao GitHub).
# cp -r COPIA a pasta inteira -- nao apaga nem move o original.
#   cp -r "$MEU_PROJETO_WINDOWS" ~/
#   cd ~/<nome-da-pasta-copiada>

# ---------------------------------------------------------------------
# Regra do dia: a partir de agora, TUDO (Docker, Kubernetes, Pulumi,
# Airflow) roda de dentro dessa pasta, dentro do terminal Ubuntu
# (WSL2), em ~ -- nunca mais atravessando para /mnt/c ou /mnt/g no
# meio dos comandos do curso.
# ---------------------------------------------------------------------
