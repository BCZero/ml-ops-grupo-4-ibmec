#!/usr/bin/env bash
# Aula 04 -- Passo a passo completo do Exemplo PCDF em Pulumi.
# Os comandos sao os MESMOS para WSL2 (Windows) e Linux -- os dois
# terminais sao Linux por baixo.

az login

mkdir -p pulumi && cd pulumi
pulumi new azure-python
# escolha um nome de projeto (ex.: pcdf-aula04) e de stack (ex.: dev)
# na primeira vez, sera pedido:
#   "Enter your passphrase to protect config/secrets:"
#   -> crie uma senha local (fica so na sua maquina, protege o
#      arquivo de state -- guarde em um cofre de senhas)

# o pulumi new acima ja cria um __main__.py de EXEMPLO generico --
# agora SUBSTITUA esse arquivo pelo codigo real do projeto PCDF.
# Escolha UMA das duas opcoes abaixo:

# Opcao A -- se main_pcdf_v2.py esta na pasta aula4_material, um nivel
# acima desta pasta pulumi/ (ajuste o caminho se for diferente):
cp ../main_pcdf_v2.py __main__.py

# Opcao B -- se preferir nao depender do caminho do material, cole o
# codigo direto no terminal (substitua a linha "cp" acima por isto):
#   cat > __main__.py << 'EOF'
#   <-- cole aqui o conteudo de main_pcdf_v2.py -->
#   EOF

pip install -r requirements.txt

# ANTES de rodar, confira a regiao liberada na SUA conta de estudante:
#   bash 04_verificar_regiao_conta_estudante.sh

pulumi config set criar_grupo true
pulumi config set localizacao eastus     # troque pela regiao liberada

pulumi preview
pulumi up
# confirme com "yes" quando perguntado

# confira em portal.azure.com -> Resource Groups -> rg-pcdf-demo

# ---------------------------------------------------------------------
# Ao final da aula -- LIMPEZA (poupa o crédito da conta de estudante):
# ---------------------------------------------------------------------
pulumi destroy
# confirme com "yes"
