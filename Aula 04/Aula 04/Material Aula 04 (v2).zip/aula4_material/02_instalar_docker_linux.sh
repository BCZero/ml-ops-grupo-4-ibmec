#!/usr/bin/env bash
# Aula 04 -- Instalar Docker Engine em uma maquina LINUX nativa.
#
# Diferenca em relacao ao Windows: aqui nunca existiu a opcao de instalar
# o "Docker Desktop" no sentido do curso -- o Docker Desktop para Linux
# tambem existe, mas NUNCA foi necessario: o Docker Engine puro, via
# linha de comando, sempre foi o caminho padrao no Linux.

# instala o Docker Engine (script oficial e convenience script da Docker)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# permite rodar "docker" sem sudo
sudo usermod -aG docker $USER

# ---------------------------------------------------------------------
# PARE AQUI: feche o terminal e abra outro (ou faca logout/login). O
# usermod acima so vale para sessoes NOVAS -- isso funciona em qualquer
# distro, sem depender de comando extra (nao use "newgrp docker": nem
# toda distro o instala por padrao).
# ---------------------------------------------------------------------

# depois de reabrir o terminal: em Linux "de verdade" (nao WSL) o systemd
# normalmente ja esta ativo, entao o servico sobe sozinho -- mas garanta
# que ele fique ligado:
sudo systemctl enable --now docker

# valida a instalacao
docker --version
docker run hello-world
docker ps
# "docker ps" vazio aqui e NORMAL: ele so lista containers RODANDO agora,
# e o hello-world ja rodou, imprimiu a mensagem e terminou (exit) sozinho.
# para ver o hello-world ja finalizado, use: docker ps -a

# ---------------------------------------------------------------------
# Se a maquina NAO tiver sudo (ambiente bem restrito), use o modo
# "rootless" do Docker em vez do script acima:
# ---------------------------------------------------------------------
#   curl -fsSL https://get.docker.com/rootless | sh
#   # o script imprime 2 export (DOCKER_HOST e PATH) -- adicione ao
#   # ~/.bashrc para nao repetir a cada terminal novo
